# CLAUDE.md — Can It Ford? Project
# Josie Cerrell, GeoElements REU, TACC/UT Austin, Summer 2026
# Canonical version — identical copy belongs at:
#   /work/11603/jcerrell0629/vista/CLAUDE.md   (Vista)
#   ~/can-it-ford/CLAUDE.md                     (Mac, git-tracked)
# Updated: July 13, 2026 — reconciles two independently-rebuilt versions, see CHANGE LOG at bottom

---

## CURRENT GOAL (the one standing priority, read this first, every session)

A real rendered MPM simulation video of the vehicle in the flooded crossing that Kumar can
actually watch. Everything else in this file is context for getting there or for the
separate SPH/L0/L1/L2 pipeline — if a session isn't advancing this goal or documenting why
it can't right now, stop and re-check that it's the right thing to be doing.

## STOP-AND-ASK LIST (no single session decides these alone)

- Whether Track 1 (mpm-engine/FloodScene) or Track 2 (Genesis-native MPM) is "the" answer
  going forward — this is a Josie call, made with full evidence from both, not a
  Claude Code session's unilateral judgment mid-debugging.
- Declaring the CURRENT GOAL above complete. A rendered video existing is not the same as
  Kumar having actually seen and accepted it — don't mark this done from inside a
  debugging session.
- Any DesignSafe publication step — separate from this file's scope entirely.

---

## WHO JOSIE IS (read this before anything else)

Non-CS first-year undergrad (Integrated Sciences, CMC). Python basics only (numpy, pandas,
matplotlib). ADHD profile, visual learner, slower processing speed.

HOW TO COMMUNICATE WITH HER IN EVERY RESPONSE:
- One default path. Never present a menu of options.
- Short chunks. No walls of text. Define technical terms inline.
- Device-tagged steps: "On MacBook:" vs "In the idev session:" vs "On iPad:"
- Explain what a command does BEFORE running it. Wait for her approval.
- If she seems stuck: shrink to TL;DR + 3 steps max. Do not add explanation.
- Feynman protocol for concepts: explain physically first, math second.
- 15-minute stuck rule: if blocked more than 15 minutes, surface the blocker.
  First contact: Cristian Moran (near-peer). Then: GeoElements Slack. Then: Hassan.
- No em-dashes in any output, any context. This was previously unstated and Claude Code
  prose violated it — now explicit.

---

## PROJECT IDENTITY

Research question: Given a real flooded road reconstructed from video, can a specific
autonomous vehicle ford it, and what is the simplest physical abstraction to answer
correctly?

Pipeline (arrow chain, memorize this):
  real flood video
  -> gsplat (Gaussian splatting reconstruction) on LS6 A100
  -> PhysGaussian kernel-to-MPM particle seeding
  -> Genesis MPM weakly-compressible water + rigid-MPM vehicle coupling on Vista GH200
  -> binary ford/no-ford verdict

Three abstraction levels:
  L0: static depth threshold only (no velocity term)
  L1: depth-velocity product H = D*V, threshold H >= 0.60 m2/s (AR&R Shand et al. 2011,
      this 0.60 figure is specifically the "Large 4WD" class, not a generic all-vehicle cutoff)
  L2: full coupled Genesis MPM simulation (buoyancy + lateral drag emerge from physics)

Framing paper: Thorpe et al. arXiv:2605.30542 "Physically Viable World Models: A Case for
Query-Conditioned Embodied AI" (co-authored by Hassan Iqbal and Cheng-Hsi Hsiao).

---

## KEY SCIENTIFIC FINDINGS (SPH pipeline — L0/L1/L2, separate from the MPM crash work below,
## untouched during July MPM debugging, presumed still accurate)

L0: NO-FORD at all depths tested (0.15, 0.30, 0.45, 0.60, 0.80m). No velocity term, static
    threshold exceeded at all test depths.
L1 at 1.5m/s: D=0.30m/H=0.45 is the key divergence point (FORD, below 0.60 threshold);
    D=0.60m/H=0.60 is NO-FORD (exactly at threshold).
L2 still water: FORD at all depths, buoyancy only. L2 open-channel at D=0.30m/V=1.5m/s:
    NO-FORD, persistent x-velocity oscillation, lateral drag exceeds friction.

CORE FINDING: L1 and L2 diverge at D=0.30m/V=1.5m/s. L1 says FORD (structurally cannot see
lateral drift). L2 says NO-FORD (detects continuous momentum accumulation L1 cannot).

MINIMUM SUFFICIENT ABSTRACTION: deep still water -> L0 sufficient. Moderate -> L1
sufficient. Fast shallow flow (0.30m/1.5m/s) -> L2 is the minimum sufficient abstraction.

---

## CLUSTER ASSIGNMENT (never mix these)

Lonestar6 (LS6): gsplat Gaussian splatting, A100 GPUs
Vista: Genesis MPM simulations, GH200 GPUs via Apptainer container

---

## KEY PATHS

This file (Vista copy) lives at: /work/11603/jcerrell0629/vista/CLAUDE.md (not in a repo)
This file (Mac copy) lives at:   ~/can-it-ford/CLAUDE.md (git-tracked)
Vista workdir:                    /work/11603/jcerrell0629/vista/
can-it-ford repo (Vista):         /work/11603/jcerrell0629/vista/can-it-ford
Track 2 MPM script:                .../can-it-ford/simulation/can_it_ford_L2_mpm.py
                                    (NOT repo root, confirmed by find, July 13)
Genesis container:                /work/10386/lsmith9003/vista/containers/genesis_container.sif
LS6 gsplat env:                    /scratch/10386/lsmith9003/python-envs/gsplat_env
TACC username:                     jcerrell0629
SSH LS6:                           ssh jcerrell0629@ls6.tacc.utexas.edu
SSH Vista:                         ssh jcerrell0629@vista.tacc.utexas.edu

Skills dir (per machine): ~/.claude/skills/
  can-it-ford-science/     -> physics, results, L0/L1/L2, validation
  can-it-ford-cluster/     -> commands, paths, Genesis methods, SLURM, error patterns
  can-it-ford-output/      -> poster, paper, abstract, Q&A, deadlines
  bug-triage-protocol/     -> multi-item triage, N-panel work assignment, added July 13,
                              install separately per machine, does not sync

---

## VISTA SESSION SETUP (always in this exact order)

Step 1: ssh jcerrell0629@vista.tacc.utexas.edu
Step 2: idev -N 1 -n 1 -p gh -t 1:30:00   (unresolved: some commands used -p gh-dev instead;
        every observed working prompt shows [gh] not [gh-dev]; run `sinfo` to confirm before
        trusting either)
Step 3: module load tacc-apptainer
Step 4: export GENESIS_PATH=/work/10386/lsmith9003/vista/containers/genesis_container.sif
Step 5: cd /work/11603/jcerrell0629/vista
Step 6: apptainer run --nv $GENESIS_PATH python3 <script>.py

gocryptfs warning: HARMLESS. Ignore it every time.

---

## GENESIS API: VERIFIED METHOD NAMES (SPH pipeline, SPHEntity specifically — MPM.Liquid's
## equivalents not separately verified, do not assume they match)

CORRECT (SPHEntity): entity.get_particles_pos() / get_particles_vel() / set_particles_vel(vel)
WRONG (throws AttributeError): entity.get_pos() / get_vel() / set_vel()

ARGPARSE ISSUE #1 (Apptainer-specific, any Genesis script): use parser.parse_known_args(),
not parse_args() — Apptainer injects positional arguments into sys.argv.

ARGPARSE ISSUE #2 (different bug, found July 12-13): can_it_ford_L2.py, can_it_ford_L2_mpm.py,
and can_it_ford_L2_mpm_ytest.py parsed --depth/--velocity via hand-rolled sys.argv[1]/[2]
indexing, never using argparse. Silently fell through to defaults for every call, invalidating
prior "isolated" crash test results. Fixed commit 69d27af, real argparse with named flags.
Scoped to exactly those 3 files, L0/L1 unaffected.

---

## SLURM DIAGNOSTICS

squeue -u jcerrell0629 / sacct -j <JOBID> --format=JobID,State,ExitCode,NodeList
Permission denied on /scratch/10386/lsmith9003/ or /work/10386/lsmith9003/:
  Do NOT debug. Slack Luke Smith (lsmith9003). Do not attempt fixes.

---

## PEOPLE AND CONTACTS

Krishna Kumar: PI, Zoom only. Hassan Iqbal: Postdoc, daily mentor, second escalation.
Cheng-Hsi Hsiao: PhD student. Cristian Moran: near-peer, FIRST CALL when stuck > 15 min.
Luke Smith: lsmith9003, environment/permission issues on shared paths.
Rosalia Gomez: REU outreach PI, receives final paper, gates stipend.
Robert Farmer: stipend/logistics, not technical.

---

## CLAUDE CODE BEHAVIOR RULES

1. PLAN MODE FIRST. Shift+Tab, show the plan, wait for approval, never auto-run.
2. EXPLAIN BEFORE EXECUTING. One sentence per command.
3. NEVER RUN GPU TRAINING ON THE LOGIN NODE. idev or sbatch only.
4. SURFACE BLOCKERS IMMEDIATELY. Missing path / permission denied / failed step: stop,
   state the exact error, identify who to contact, wait.
5. GREP THE REPO, DON'T PASTE IT. grep -n "def " <file>, never load a full codebase.
6. ONE TASK PER TURN. Do not chain tasks or offer options. Confirm success, ask what's next.
7. COMPACT WHEN CONTEXT FILLS. /compact before it bloats silently.
8. FORMAL TEXT RULES (poster/paper): no gsplat version numbers, no allocation IDs, no
   em-dashes. Cite arXiv:2605.30542 for PVWM. Josie's contribution is the pipeline and
   abstraction-ladder experiment, not the framework.
9. STANDING ORIENTATION RULE, added July 13 — before proposing any new work:
   a. Read this file, SESSION_STATE.md, PROVISIONAL_STATUS.md, kumar_july9_update/STATUS.md.
   b. Run `git log --oneline -15` and `git status`. Trust this over any written summary.
   c. Check `logs/*_result.md` for findings not yet folded into STATUS.md.
   d. State what you understand has already been tried, wait for correction before running.
   e. Confirm shell state via `hostname; pwd` before any ssh/idev command.

---

## SKILL ROUTING

Physics/results/science -> can-it-ford-science
Cluster/terminal/debugging/API -> can-it-ford-cluster
Poster/paper/Q&A/deadlines -> can-it-ford-output
Multi-item bug triage / N-panel assignment -> bug-triage-protocol

---

## VALIDATION DATA

NWS: 0.15m loss-of-control risk, 0.30m carries away most cars, 0.60m carries away SUVs/trucks.
Smith, Modra & Felder 2019 (JFRM 12:e12527): sedan unstable ~0.15m, 4WD unstable ~0.30m in
  fast flow. Does NOT contain a displacement-distance equation — do not cite it for
  DRIFT_THRESHOLD, see below.
AR&R Shand et al. 2011: H=D*V, H>=0.60 -> Large 4WD unsafe (not generic all-vehicle).

---

## GENESIS MPM SCENE SETUP — SPH PIPELINE SPECIFIC, do not apply to Track 2's
## can_it_ford_L2_mpm.py without re-verifying against MPM.Liquid's actual API

Water: SPHEntity. Vehicle: RigidEntity. Coupling: rigid_mpm_coupler.
Instability detection: monitor vehicle x-velocity; persistent non-decaying oscillation in
open-channel = lateral instability = NO-FORD.

---

## VISTA MPM TASK CONTEXT (added July 8, corrected July 13 twice — once for stale claims,
## once for the ruled-out crash causes below)

Kumar's task, verbatim: "can you run what Cheng-Hsi has first?
https://github.com/kks32/mpm-engine is the MPM engine." Real car, real MPM, real
SDF-mesh-to-rigid-body coupling. Not a box, not the SPH pipeline.

### Three tracks — do not conflate

- Track 1 — mpm-engine/FloodScene (examples/flood_vehicle.py): WORKING. Real mesh via
  plyfile (truck_trimmed.ply leading candidate, not independently confirmed as default).
  Full 6-DOF output. Closest match to Kumar's ask.
- Track 2 — Genesis-native MPM, can-it-ford/simulation/can_it_ford_L2_mpm.py: crash under
  active investigation, see below.
- can_it_ford_L2.py / can_it_ford_L2_new.py: separate SPH pipeline. Do not touch unless
  named explicitly.

### MASS-BUG (Track 2, open as of July 13)

rho=604 was calibrated for the OLD box (1.0x1.6x1.5m, ~1450kg). Never recalculated after
resize to the real sedan bbox (4.66x1.79x1.44m, commit 67915be). Current live mass is
approximately 7255kg. Correct rho is 115.7. Mass target confirmed as 1390kg (matches
vehicle_params.py's NHTSA/SAE citation, used consistently across Track 1 and later
debugging sessions) — the earlier 1450kg alternative is retired, do not use it.

### CUDA_ERROR_ILLEGAL_ADDRESS crash (Track 2), status as of July 13 morning

RULED OUT, individually tested: grid_density, domain padding, box size, vehicle position
(the water/vehicle overlap hypothesis — the vehicle sitting at z=0.755 for partial
submersion is intentional per Kumar's own diagram feedback, and repositioning it does not
stop the crash), the argparse bug.
LIVE HYPOTHESIS: the domain-widening commit itself is the regression, independent of what
geometry sits inside it. Domain bounds in question: lower_bound=(-2.5,-1.0,-0.1),
upper_bound=(4.5,1.0,2.5). Mechanism not yet identified. Mass has NOT been tested in
combination with this — do not assume it's cleared.
grid_density has flip-flopped between 64 and 128 across at least three commits (87c1bda,
7e5f9f4, 7f7fdb2) historically — grep fresh regardless of the ruled-out status above.

### DRIFT_THRESHOLD = 0.05m, resolved

No peer-reviewed source defines this as a displacement threshold. Do not cite "Smith et al.
2019, Eq. 6" — no such equation exists. Correct framing: a conservative numerical
onset-of-motion tolerance internal to the solver, roughly 2.5-3.4% of vehicle body width.
Cite Xia et al. 2014 (DOI 10.1007/s11069-013-0889-2) and Shah et al. 2018
(DOI 10.1051/matecconf/201820307003) for the underlying physics if a citation is needed.

### VIABILITY-AUDIT-GLOB-BUG (new, found July 13)

analysis/viability_audit.py globs `particles_d*.npz`, which matches
`particles_d1p0_v3p0.npz` but does NOT match `particles_mpm_*.npz` files. Every MPM-track
output has been structurally invisible to this audit script. Fix-applied status
unconfirmed as of July 13 — check before trusting any viability_audit.py output.

### CONDA-ACTIVATION-BUG (Mac, resolved July 13)

`conda run -n can-it-ford python3 -c "import trimesh"` failed with ModuleNotFoundError
despite trimesh being installed in that environment. Root cause: `conda run -n can-it-ford
which python3` resolves to `/opt/homebrew/bin/python3` (system Python), not the
environment's own interpreter — `conda run` is not actually activating the environment.
Use the environment's literal interpreter path directly, or fix conda's shell
initialization, rather than relying on `conda run`.

### Vehicle mesh

Track 1 loads a real mesh via plyfile — the earlier "no confirmed car mesh exists" claim
is retired. Which specific mesh file it defaults to was not independently confirmed as of
July 13.

### House rules for any code written here

No inline code comments, no docstrings, any file, any language. Explanations belong in
chat, not code. Exact commands, not vague suggestions. State what success looks like and
the most likely failure mode after each step.

---

## CHANGE LOG

July 13, morning: reconciled two independently-rebuilt versions of this file (one built in
a Vista-focused session, one in a Mac-focused session that used different bug-ID
terminology). Retired numeric bug IDs (B01-B15 / Bug 1-3 / Cluster A-D) in favor of
descriptive slugs to prevent future ID collisions across sessions. Corrected the crash
root-cause section with the actual ruled-out list (grid_density, domain padding, box size,
vehicle position, argparse all cleared; domain bounds now the live hypothesis) — a version
of this file written earlier the same night was already stale on this point within about
an hour. Resolved the 1390kg vs 1450kg mass-target ambiguity in favor of 1390kg. Added two
new items (viability_audit.py glob bug, conda activation root cause) not present in either
prior version. Added CURRENT GOAL and STOP-AND-ASK sections. Everything else preserved
from the original July 8 file, not re-verified this pass.
