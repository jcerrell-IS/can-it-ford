# CLAUDE.md — Can It Ford? Project
# Josie Cerrell, GeoElements REU, TACC/UT Austin, Summer 2026
# Place this file at: /work/11603/jcerrell0629/vista/CLAUDE.md
# Updated: July 13, 2026 (see change log at the bottom)

---

## WHO JOSIE IS (read this before anything else)

Non-CS first-year undergrad (Integrated Sciences, CMC). Python basics only (numpy, pandas,
matplotlib). ADHD profile, visual learner, slower processing speed.

HOW TO COMMUNICATE WITH HER IN EVERY RESPONSE:
- One default path. Never present a menu of options.
- Short chunks. No walls of text. Define technical terms inline.
- Device-tagged steps: "On MacBook:" vs "In the idev session:" vs "On iPad:"
- Explain what a command does BEFORE running it. Wait for her approval.
- If she seems stuck: shrink to TL;DR + 3 steps max. Do not add explanation.
- Feynman protocol for concepts: explain physically first, math second.
- 15-minute stuck rule: if blocked more than 15 minutes, surface the blocker.
  First contact: Cristian Moran (near-peer). Then: GeoElements Slack. Then: Hassan.

---

## PROJECT IDENTITY

Research question: Given a real flooded road reconstructed from video, can a specific
autonomous vehicle ford it, and what is the simplest physical abstraction to answer
correctly?

Pipeline (arrow chain, memorize this):
  real flood video
  -> gsplat (Gaussian splatting reconstruction) on LS6 A100
  -> PhysGaussian kernel-to-MPM particle seeding
  -> Genesis MPM weakly-compressible water + rigid-MPM vehicle coupling on Vista GH200
  -> binary ford/no-ford verdict

Three abstraction levels:
  L0: static depth threshold only (no velocity term)
  L1: depth-velocity product H = D*V, threshold H >= 0.60 m2/s (AR&R Shand et al. 2011,
      this 0.60 figure is specifically the "Large 4WD" class, not a generic all-vehicle cutoff)
  L2: full coupled Genesis MPM simulation (buoyancy + lateral drag emerge from physics)

Framing paper: Thorpe et al. arXiv:2605.30542 "Physically Viable World Models: A Case for
Query-Conditioned Embodied AI" (co-authored by Hassan Iqbal and Cheng-Hsi Hsiao).

---

## PROJECT STATE SNAPSHOT, June 27, 2026 (historical — superseded by VISTA MPM TASK
## CONTEXT below for Track 2 status; not re-verified tonight)

DONE (as of June 27):
  - All three tutorials complete (garden gsplat, custom video splat, Genesis MPM ball)
  - Abstract finalized with Kumar's edits, submitted June 18 to Rosalia Gomez
  - L0, L1, L2 scripts written and run
  - Validation figure complete: ~/can_it_ford_validation.png (MacBook)
  - Core scientific finding confirmed (see KEY SCIENTIFIC FINDINGS below)

Deadlines (confirmed still accurate as of July):
  - Poster build and upload by July 27
  - Mock session July 28
  - Poster session July 30, Perry-Castañeda Library UFCU Room, 1:00-2:30pm
  - Final paper due July 31 (email Rosalia Gomez, Cc mentor) -> GATES FINAL STIPEND

---

## KEY SCIENTIFIC FINDINGS (SPH pipeline — L0/L1/L2, not re-verified since June 27,
## presumed still accurate since this pipeline was untouched during the July MPM work)

L0 result: NO-FORD at all depths tested (0.15, 0.30, 0.45, 0.60, 0.80m).
  Reason: No velocity term. Static threshold. All test depths exceed it.
  Validation figure: flat NO-FORD line (blue squares) across all depths.

L1 result at 1.5m/s:
  D=0.15m: H=0.225, FORD
  D=0.30m: H=0.45, FORD  <-- KEY DIVERGENCE POINT
  D=0.60m: H=0.60, NO-FORD (exactly at threshold)
  D=0.80m: H=0.40, FORD (velocity decreases at greater depth)
  Validation figure: non-monotonic green triangle line.

L2 still water: FORD at all depths. Zero net horizontal flow. Buoyancy only.
  Validation figure: flat FORD line (red circles) across all depths.

L2 open-channel at D=0.30m, V=1.5m/s: NO-FORD.
  Mechanism: persistent x-velocity oscillation. Continuous lateral drag exceeds friction.
  Validation figure: single dark red X at D=0.30m/V=1.5m/s.

CORE FINDING (say this exactly):
  L1 and L2 diverge at D=0.30m / V=1.5m/s.
  L1 calls FORD (H=0.45, below 0.60 threshold).
  L2 calls NO-FORD (persistent x-velocity oscillation from lateral drag).
  L2 detects a danger mode that L1 structurally cannot: continuous momentum accumulation.

MINIMUM SUFFICIENT ABSTRACTION:
  Deep still water -> L0 is sufficient.
  Moderate conditions -> L1 is sufficient.
  Fast shallow flow (0.30m/1.5m/s) -> L2 is the minimum sufficient abstraction.

---

## CLUSTER ASSIGNMENT (never mix these)

Lonestar6 (LS6): gsplat Gaussian splatting, A100 GPUs
Vista: Genesis MPM simulations, GH200 GPUs via Apptainer container

---

## KEY PATHS

This file lives at:       /work/11603/jcerrell0629/vista/CLAUDE.md  (confirmed correct
                            path, verified July 13 — this file is NOT inside a git repo,
                            no parent .git found up to the filesystem boundary)
Vista workdir:             /work/11603/jcerrell0629/vista/
can-it-ford repo:          /work/11603/jcerrell0629/vista/can-it-ford  (this IS a git repo,
                            remote: https://github.com/jcerrell-IS/can-it-ford.git)
Track 2 MPM script:        /work/11603/jcerrell0629/vista/can-it-ford/simulation/can_it_ford_L2_mpm.py
                            (NOT repo root — confirmed by direct find, July 13. The repo
                            root layout has shifted before; always confirm with find, do
                            not assume.)
Genesis container:         /work/10386/lsmith9003/vista/containers/genesis_container.sif
Genesis examples:          $WORK/genesis-world/examples/coupling/
LS6 gsplat env:            /scratch/10386/lsmith9003/python-envs/gsplat_env
LS6 garden data:           /scratch/10386/lsmith9003/src/nerf_studio/gsplat/examples/data/360_v2/garden/
Validation figure:         ~/can_it_ford_validation.png (MacBook, not on cluster)
TACC username:             jcerrell0629
SSH LS6:                   ssh jcerrell0629@ls6.tacc.utexas.edu
SSH Vista:                 ssh jcerrell0629@vista.tacc.utexas.edu

Skills dir (this cluster): ~/.claude/skills/
  can-it-ford-science/   -> physics, results, L0/L1/L2, validation
  can-it-ford-cluster/   -> commands, paths, debugging, API
  can-it-ford-output/    -> poster, paper, abstract, Q&A, deadlines
  bug-triage-protocol/   -> multi-item triage, N-panel work assignment, added July 13

---

## VISTA SESSION SETUP (always in this exact order)

Step 1:  ssh jcerrell0629@vista.tacc.utexas.edu
Step 2:  idev -N 1 -n 1 -p gh -t 1:30:00
Step 3:  module load tacc-apptainer
Step 4:  export GENESIS_PATH=/work/10386/lsmith9003/vista/containers/genesis_container.sif
Step 5:  cd /work/11603/jcerrell0629/vista
Step 6:  apptainer run --nv $GENESIS_PATH python3 <script>.py

NOTE on Step 2's partition flag: this file says `-p gh`. Some commands given tonight
(July 13) used `-p gh-dev` instead, and every real compute-node prompt observed tonight
showed `[gh]`, never `[gh-dev]`. Unconfirmed whether these are the same partition family
or genuinely different — run `sinfo` or `idev --help` to check before trusting either
blindly. Default to `-p gh` (this file's original value) until confirmed otherwise.

gocryptfs warning: HARMLESS. Ignore it every time.

---

## LS6 SESSION SETUP (gsplat only)

Step 1:  ssh jcerrell0629@ls6.tacc.utexas.edu
Step 2:  idev -N 1 -n 1 -p gpu-a100-dev -t 2:00:00
Step 3:  source /scratch/10386/lsmith9003/python-envs/gsplat_env/bin/activate
Step 4:  cd $SCRATCH/gsplat/examples

Training:
  CUDA_VISIBLE_DEVICES=0 python3 simple_trainer.py default \
    --data_dir /scratch/10386/lsmith9003/src/nerf_studio/gsplat/examples/data/360_v2/garden/ \
    --max_steps 3000 --eval_steps 3000 --save-ply

Results: results/garden/videos/traj_2999.mp4
SCP to MacBook: scp jcerrell0629@ls6.tacc.utexas.edu:<full_path>/results/garden/videos/traj_2999.mp4 ~/Desktop/

---

## GENESIS API: VERIFIED METHOD NAMES (SPH pipeline — SPHEntity specifically; MPM.Liquid's
## equivalent accessor methods have not been separately verified, do not assume they match)

CORRECT (use only these for SPHEntity):
  entity.get_particles_pos()      # particle positions, N x 3
  entity.get_particles_vel()      # particle velocities, N x 3
  entity.set_particles_vel(vel)   # set particle velocities

WRONG (throw AttributeError, never suggest):
  entity.get_pos() / entity.get_vel() / entity.set_vel()

Inspect methods inside container:
  grep -n "def " /code/genesis-world/genesis/engine/entities/sph_entity.py
  NOTE: dir() fails due to Genesis scene initialization requirements.

ARGPARSE ISSUE #1 (Apptainer-specific, applies to any Genesis script run via Apptainer):
  Use parser.parse_known_args() NOT parser.parse_args()
  Reason: Apptainer injects positional arguments into sys.argv.

ARGPARSE ISSUE #2 (a DIFFERENT bug, found July 12-13, do not conflate with #1 above):
  can_it_ford_L2.py, can_it_ford_L2_mpm.py, and can_it_ford_L2_mpm_ytest.py previously
  parsed --depth/--velocity via hand-rolled sys.argv[1]/sys.argv[2] positional indexing,
  never using argparse at all. This silently fell through to defaults (depth=0.30,
  velocity=0.0) for every --depth/--velocity call, invalidating days of prior "isolated"
  crash test results. Fixed in commit 69d27af with real argparse and named flags.
  Confirmed scoped to exactly those 3 files; L0/L1 scripts were never affected.

---

## SLURM DIAGNOSTICS

squeue -u jcerrell0629
sacct -j <JOBID> --format=JobID,State,ExitCode,NodeList
cat <jobname>.err | cat <jobname>.out

LS6 partition: gpu-a100-dev
Vista partition: gh
Both: --nodes=1 --ntasks=1 --time=02:00:00

Permission denied on /scratch/10386/lsmith9003/ or /work/10386/lsmith9003/:
  Do NOT debug. Slack Luke Smith (username: lsmith9003). Do not attempt fixes.

---

## PEOPLE AND CONTACTS

Krishna Kumar:    PI, Zoom only. Intellectual direction. Allocation access.
Hassan Iqbal:     Postdoc, daily technical mentor. Second escalation.
Cheng-Hsi Hsiao: PhD student, may assign new videos to splat.
Cristian Moran:   Near-peer. FIRST CALL when stuck > 15 minutes. Before Slack or Hassan.
Luke Smith:       lsmith9003 on Slack. Environment and permission issues on shared paths.
Rosalia Gomez:    REU outreach PI. Receives abstract and final paper. Paper gates stipend.
Robert Farmer:    Stipend, logistics, travel reimbursement. Not technical questions.

---

## CLAUDE CODE BEHAVIOR RULES FOR THIS PROJECT

1. PLAN MODE FIRST. Before editing or running anything: Shift+Tab to Plan Mode.
   Show the plan, wait for Josie to say go. Never auto-run without approval.

2. EXPLAIN BEFORE EXECUTING. One sentence per command explaining what it does.
   "This command activates the gsplat Python environment stored in Luke's shared space."

3. NEVER RUN GPU TRAINING ON THE LOGIN NODE. Always use idev or sbatch. If unsure
   which node you're on, run hostname and check before any CUDA command.

4. SURFACE BLOCKERS IMMEDIATELY. If a path is missing, a permission is denied, or a
   step fails: stop, state the exact error, identify who to contact (Luke/Cristian/Hassan),
   and wait. Do not attempt workarounds on lsmith9003 paths.

5. GREP THE REPO, DON'T PASTE IT. For any Genesis or gsplat API question:
   grep -n "def " <path_to_source_file>
   Do not try to load the full codebase into context.

6. ONE TASK PER TURN. Josie has ADHD. Do not chain multiple tasks or offer options.
   Complete one action, confirm success (show relevant output), then ask what's next.

7. COMPACT WHEN CONTEXT FILLS. If the session gets slow or starts losing track of earlier
   steps, run /compact before continuing. Do not let context bloat silently.

8. FORMAL TEXT RULES. If writing anything that will go in the poster or paper:
   No gsplat version numbers. No allocation IDs. No "the GeoElements group introduced..."
   Use Kumar's approved framing. Cite arXiv:2605.30542 for PVWM concepts.
   Josie's contribution: the pipeline and abstraction-ladder experiment. Not the framework.

9. STANDING ORIENTATION RULE, added July 13 — read before proposing any new work:
   a. Read this file, SESSION_STATE.md, PROVISIONAL_STATUS.md, and
      kumar_july9_update/STATUS.md (all in the can-it-ford repo) in full.
   b. Run `git log --oneline -15` and `git status` inside the can-it-ford repo.
      Trust this over any written summary if they conflict — commits are ground truth.
   c. Check `logs/*_result.md` in the repo for recent findings not yet folded into STATUS.md.
   d. State a short summary of what you understand has already been tried or resolved,
      and wait for confirmation or correction before running anything.
   e. Confirm current shell state (login node / compute node / local Mac) via
      `hostname; pwd` before prescribing any ssh/idev command. Never chain ssh and idev
      blindly — check which one actually applies first.

---

## SKILL ROUTING (load the right skill for the task)

Physics / results / science questions:
  -> load can-it-ford-science (L0/L1/L2 findings, validation data, pipeline mechanics)

Cluster / terminal / debugging / API questions:
  -> load can-it-ford-cluster (commands, paths, Genesis methods, SLURM, error patterns)

Poster / paper / Q&A / abstract / deadlines:
  -> load can-it-ford-output (approved abstract, talking points, paper structure, contacts)

Multi-item bug triage / assigning work across N terminal panes:
  -> load bug-triage-protocol (added July 13)

---

## VALIDATION DATA (cite these exactly)

NWS thresholds:
  0.15m (6 in):  reaches bottom of most passenger cars, loss of control risk
  0.30m (12 in): "takes just 12 inches of rushing water to carry away most cars"
  0.60m (24 in): "just 2 feet can carry away SUVs and trucks"

Smith, Modra & Felder 2019 (Journal of Flood Risk Management 12:e12527):
  Sedan unstable at approximately 0.15m in fast flow
  4WD unstable at approximately 0.30m in fast flow
  NOTE: this paper does NOT contain a displacement-distance equation. Do not cite it for
  DRIFT_THRESHOLD (0.05m) — that attribution was checked in detail July and found false.
  See DRIFT_THRESHOLD note under VISTA MPM TASK CONTEXT below for the correct framing.

AR&R Shand et al. 2011:
  H = D * V (m2/s). H >= 0.60 -> Large 4WD unsafe (not a generic all-vehicle threshold,
  the report itself calls its thresholds "draft, interim, informal").
  H < 0.30 -> generally safe (H1 zone).

---

## GENESIS MPM SCENE SETUP — SPH PIPELINE SPECIFIC, do not apply to Track 2's
## can_it_ford_L2_mpm.py without re-verifying against MPM.Liquid's actual API first

Water entity:    SPHEntity (weakly-compressible SPH, free-surface flow)
Vehicle entity:  RigidEntity
Coupling:        rigid_mpm_coupler (Newton's 3rd law, enabled by default)

Still water:    Closed domain, no inflow, gravity only.
Open-channel:   Continuous inflow on one face, outflow on opposite face, target velocity.

Instability detection:
  Monitor vehicle x-velocity (lateral direction) each timestep.
  Still water: x-velocity stays near zero (buoyancy acts vertically only).
  Open-channel: persistent oscillation that doesn't decay = lateral instability = NO-FORD.
  Ford threshold: if RMS x-velocity remains above noise floor after N timesteps -> NO-FORD.

---

## WHAT CLAUDE CODE CAN AND CANNOT DO ON THIS PROJECT

CAN:
  Write and debug Python scripts for L0/L1/L2 abstraction logic
  Run Genesis simulations via Apptainer on Vista
  Run gsplat training on LS6 A100 nodes via idev
  Read Genesis and gsplat source code via grep
  Check SLURM job status, read .err and .out logs
  Draft poster text, figure captions, paper sections in Plan Mode
  Search the GeoElements repo without ingesting the full codebase

CANNOT:
  Modify files in /scratch/10386/lsmith9003/ or /work/10386/lsmith9003/ (Luke's space)
  Access Josie's MacBook filesystem from Vista
  Run the validation figure script (lives on MacBook, not on cluster)
  Reach Otter.ai, Slack, or Gmail from the cluster (use Claude.ai Projects for that)

---

## VISTA MPM TASK CONTEXT (added July 8, 2026, substantially corrected July 13, 2026)

This section covers a NEW task from Kumar, distinct from the SPH L0/L1/L2 pipeline above.
Read it fully before doing anything on the MPM task.

### The task, verbatim from Kumar in Slack (this is the authority)

Kumar to Josie, direct message:
  "can you run what Cheng-Hsi has first? https://github.com/kks32/mpm-engine is the MPM engine."

Fuller thread context: Kumar wants a real car imported into a real MPM simulation of a
flooded crossing, using real SDF-mesh-to-rigid-body coupling ("I have an MPM with SDF with
any mesh to rigid body"), not a placeholder box, not the SPH pipeline described above.

### Three tracks exist as of July 13 — do not conflate them

- Track 1 — mpm-engine/FloodScene (examples/flood_vehicle.py, kks32/mpm-engine repo,
  Kumar's own reference implementation): WORKING. Loads a real mesh via plyfile
  (truck_trimmed.ply is the leading candidate for the default, not independently
  confirmed). Produces full 6-DOF yaw/roll/lateral-drift output. Closest match to
  Kumar's literal ask above.
- Track 2 — Genesis-native MPM, can_it_ford_L2_mpm.py, at
  can-it-ford/simulation/can_it_ford_L2_mpm.py (confirmed path, NOT repo root). Open,
  unresolved CUDA_ERROR_ILLEGAL_ADDRESS crash under active investigation as of July 13.
- can_it_ford_L2.py and can_it_ford_L2_new.py (no "_mpm") are a THIRD, separate SPH
  pipeline, confirmed running gs.materials.SPH.Liquid, not MPM. Do not edit, run, or
  reference these as part of the MPM task unless explicitly asked for by name.

### Track 2 (can_it_ford_L2_mpm.py) status as of July 13 — read before touching this file

- Open bug: vehicle density (rho=604) was calibrated for the OLD placeholder box
  (1.0x1.6x1.5m, ~1450kg target) and was never recalculated after the box was resized to
  the real sedan bbox (4.66x1.79x1.44m, commit 67915be). Current live mass is
  approximately 7255kg. Correct rho is 115.7 for a 1390kg target (matches
  vehicle_params.py's NHTSA/SAE citation, used by Track 1) or 120.7 for the older 1450kg
  target used elsewhere in this file — these two targets disagree by about 4% and one
  should be picked and used consistently; not yet resolved as of July 13.
- Commit 8d1ea39 ("Re-apply Genesis L2 MPM fixes lost in rebase conflict resolution")
  documents a water-box-overlap fix and floor clearance that had been lost in an earlier
  rebase and was restored. The later sedan-resize commit (67915be) does not mention
  re-deriving this for the new box dimensions — check `git show 8d1ea39` on this file
  before writing a new overlap fix from scratch, the old fix's logic may just need
  updating for the current box size rather than reinventing.
- grid_density has flip-flopped between 64 and 128 across at least three separate
  commits (87c1bda, 7e5f9f4, 7f7fdb2). Grep it fresh every time, never trust a
  remembered or documented value.
- Friction: 0.55, citing Azhar et al. 2023, confirmed correctly set in commit 5d23037,
  matches the value already validated in the SPH script — no discrepancy here.
- can_it_ford_L2_mpm_ytest.py exists alongside the main script (168 lines, created in
  the same commit as the argparse fix). Purpose relative to the main script unconfirmed
  as of July 13 — diff before assuming it's a duplicate or safe to delete.

### DRIFT_THRESHOLD = 0.05m citation, resolved July 13

No peer-reviewed source defines a 0.05m lateral-displacement threshold for vehicle flood
instability. Do not cite "Smith et al. 2019, Eq. 6" for this — that equation does not
exist in that paper. Correct framing: DRIFT_THRESHOLD is a conservative numerical
onset-of-motion detection tolerance internal to the solver (not a physical criterion),
corresponding to roughly 2.5-3.4% of representative vehicle body width. Cite Xia et al.
2014 (DOI 10.1007/s11069-013-0889-2) and Shah et al. 2018 (DOI 10.1051/matecconf/201820307003)
for the underlying incipient-motion physics if a citation is needed for this value.

### Vehicle mesh — corrected, this was stale

The July 8 version of this file said no confirmed car mesh existed anywhere in the
project. That is no longer accurate: Track 1's FloodScene loads a real mesh via plyfile.
Which specific mesh file it defaults to (truck_trimmed.ply vs. something else) was not
independently confirmed as of July 13 — check before assuming it's a car and not a
mislabeled truck placeholder.

### House rules for any code written here

No inline code comments, no docstrings, in any file, any language. Explanations belong
in chat responses, not in the code itself. Give exact commands, not vague suggestions. State
what success looks like after each step, and the most likely failure mode, before moving
on to the next step.

---

## CHANGE LOG

July 13, 2026: Corrected stale July 8 claims (car mesh existence, vehicle mass note without
warning about the resize regression). Added Track 2's confirmed path, the mass-target
ambiguity, the overlap-fix history, grid_density instability, the second (distinct)
argparse bug, the resolved DRIFT_THRESHOLD citation, and the standing orientation rule.
Flagged an unresolved discrepancy on the idev partition flag (gh vs gh-dev) rather than
silently picking one. Everything not explicitly called out above is unchanged from the
July 8 version and was not re-verified tonight — treat accordingly.
